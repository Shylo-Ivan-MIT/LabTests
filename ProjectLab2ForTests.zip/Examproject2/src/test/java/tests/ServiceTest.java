/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tests;

import org.obrii.mit.dp2021.crud.DataList;


/**
 *
 * @author Користувач
 */
public class ServiceTest {
    
    public DataList Test;
    
    DataList data = new DataList(3, "Pencil", 15, 2, "Jeb", 30, "street", true);
    
}
